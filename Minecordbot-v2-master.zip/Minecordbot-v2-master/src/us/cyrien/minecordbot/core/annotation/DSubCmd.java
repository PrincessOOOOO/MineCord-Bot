package us.cyrien.minecordbot.core.annotation;


public @interface DSubCmd {
}
