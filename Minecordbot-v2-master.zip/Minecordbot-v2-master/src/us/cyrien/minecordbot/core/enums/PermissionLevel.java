package us.cyrien.minecordbot.core.enums;

public enum PermissionLevel {
    LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3, OWNER, CYRIEN
}
